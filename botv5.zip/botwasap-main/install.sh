pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install mc
pkg install tesseract
pkg install nodejs
pkg install wget
pkg install ffmpeg
clear
npm i -g ytdl
npm i -g cwebp
npm i node-tesseract-ocr
npm i got
npm i
clear
echo "[*]udah selesai nih. Tinggal ketik node index.js"
